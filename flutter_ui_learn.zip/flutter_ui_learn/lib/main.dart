import 'package:flutter/material.dart';
import 'package:flutter_learn/screens/landing_page.dart';
import 'package:flutter_learn/utils/constans.dart';
import 'dart:ui';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    double screenWidth = window.physicalSize.width;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Design 1',

      theme: ThemeData(
        primaryColor: COLOR_WHITE,
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: COLOR_DARK_BLUE
        ),
        textTheme: TEXT_THEME_DEFAULT,
        fontFamily: 'Montserrat'
      ),

      home: const LandingPage(),
    );
  }
}
