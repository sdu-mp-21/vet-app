import 'package:flutter/material.dart';
import 'package:flutter_learn/utils/widget_functions.dart';
import 'package:flutter_learn/custom/border_box.dart';
import 'package:flutter_learn/utils/constans.dart';



class RealEstateItem extends StatelessWidget {
  final dynamic itemData;

  const RealEstateItem({Key? key, @required this.itemData}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final ThemeData themeData = Theme.of(context);

    return GestureDetector(
      // onTap: () {
      //   Navigator.of(context).push(MaterialPageRoute(
      //       builder: (context) => DetailPage(
      //             itemData: itemData,
      //           )));
      // },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(borderRadius: BorderRadius.circular(25.0), child: Image.asset(itemData["image"])),
                const Positioned(
                  top: 15,
                  right: 15,
                  child: BorderBox(
                    child: Icon(
                      Icons.favorite_border,
                      color: COLOR_BLACK
                    ),
                    height: 50,
                    width: 50,
                    padding: EdgeInsets.all(8.0),
                  ),
                )
              ],
            ),
            addVerticalSpace(15),
            Row(
              children: [
                Text(
                  // formatCurrency(itemData["amount"]),
                  '2000000',
                  style: themeData.textTheme.headline1,
                ),
                addHorizontalSpace(10),
                Text(
                  "${itemData["address"]}",
                  style: themeData.textTheme.bodyText2,
                )
              ],
            ),
            addVerticalSpace(10),
            Text(
              "${itemData["bedrooms"]} bedrooms / ${itemData["bathrooms"]} bathrooms / ${itemData["area"]} sqft",
              style: themeData.textTheme.headline5,
            )
          ],
        ),
      ),
    );
  }
}
