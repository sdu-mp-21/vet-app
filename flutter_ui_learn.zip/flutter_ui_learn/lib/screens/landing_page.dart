import 'package:flutter/material.dart';
import 'package:flutter_learn/custom/border_box.dart';
import 'package:flutter_learn/utils/constans.dart';
import 'package:flutter_learn/utils/sample_data.dart';
import 'package:flutter_learn/utils/widget_functions.dart';
import 'package:flutter_learn/custom/choice_option.dart';
import 'package:flutter_learn/custom/real_estate_item.dart';


class LandingPage extends StatelessWidget {
  const LandingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final ThemeData themeData = Theme.of(context);
    double padding = 25;
    final sidePadding = EdgeInsets.symmetric(horizontal: padding);

    return SafeArea(
      child: Scaffold(
        body: Container(
          height: size.height,
          width: size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              addVerticalSpace(25),
              Padding(
                padding: sidePadding,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    BorderBox(
                      padding: EdgeInsets.all(8.0),
                      height: 50, 
                      width: 50, 
                      child: Icon(Icons.menu, color: COLOR_BLACK)),

                    BorderBox(
                      padding: EdgeInsets.all(8.0),
                      height: 50, 
                      width: 50, 
                      child: Icon(Icons.settings_suggest_sharp, color: COLOR_BLACK)),
                  ],
                ),
              ),
              addVerticalSpace(20),
              Padding(
                padding: sidePadding ,
                child: Text(
                      "City",
                      style: themeData.textTheme.bodyText2,
                    ),
              ),
              addVerticalSpace(10),
              Padding(
                padding: sidePadding,
                child: Text(
                  "San Francisco",
                  style: themeData.textTheme.headline1,
                ),
              ),
              Padding(
                padding: sidePadding,
                child: const Divider(
                height: 25,
                color: COLOR_GREY,)
              ),
              addVerticalSpace(10),
              SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: ["<\$220,000","For Sale","3-4 Beds",">1000 sqft"]
                        .map((filter) => ChoiceOption(text: filter)).toList(),
                  ),
                ),
              addVerticalSpace(10),

              Expanded(
                child: Padding(
                  padding: sidePadding,
                  child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: RE_DATA.length,
                    itemBuilder: (context, index){
                      return RealEstateItem(
                        itemData: RE_DATA[index],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}